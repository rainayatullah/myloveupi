#'@import pracma
residu = function(y, s1, knot, nknot, p){
  m = ncol(s1)
  n = nrow(s1)
  alpha = matrix(nrow=1,ncol=m)
  for (i in 1:m){
    alpha[1,i]= p[i] + 1 + nknot
  }
  ncolx = sum(alpha)
  X = matrix(0, nrow=n, ncol=alpha)
  for (k in 1:m){
    X1 = matrix(0, nrow=n, ncol=alpha[,k])
    for (c in 1:alpha[1,k]){
      for (r in 1:n){
        if (c <= (p[m]+1)){
          X1[r,c]=x[r,k]^(c-1)
        }else{
          X1[r,c] = truncated(s1[r,k],knot[(m-(p[m]+1)),k],p[m])
        }
      }
    }
    if (k==1){
      X=X1
    }else{
      X=cbind(X,X1)
    }
  }
  I = diag(nrow(s1))
  tetha = pinv((t(X)%*%X))%*%t(X)%*%(y)
  H = X%*%pinv((t(X)%*%X))%*%t(X)
  yhat = X%*%tetha
  M = y-yhat
  return(mean(abs(M/y)))
}
