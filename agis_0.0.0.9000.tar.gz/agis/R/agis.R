#'Implementasi Algortima Genetika dalam mengoptimisasi parameter regresi truncated spline
#'@export
#'@param y vektor / array yang merupakabn variabel respon
#'@param x matrix yang merupakan kumpulan variabel prediktor
#'@param a jumlah individu awal (secara default ditentukan bernilai 10)
#'@param iterasi jumlah perulangan optimisasi (secara default ditentukan bernilai 7)
#'@param nknot jumlah titik knot (secara default ditentukan bernilai 2)
#'@param orde orde maksimum prediktor (secara default bernilai 2)
#'@param p kombinasi orde (secara default ditentukan acak berdasarkan parameter orde)
agis=function(y,x,a=10,iterasi=7,nknot=2,orde=2,p=c()){
  s1 = as.matrix(x)
  nvar = ncol(x)
  b = ncol(s1)
  if (length(p)==0){
    p=sample (1:orde,nvar,replace = T)
  }

  if (a>1){
    popA1 = matrix(0, nrow=nknot*a, ncol=b)
    for ( i in 1:(nknot*a)){
      for (j in 1:b){
        popA1[i,j]= sample(min(s1[,j]):max(s1[,j]),1)
      }
    }
  }
  plotGCV=c()
  for (generasi in 1:iterasi){
    GCV =  matrix(0, nrow=((length(popA1)/b)/nknot), ncol=1)
    for (i in 1:nrow(GCV)){
      knot = popA1[(((i-1)*nknot)+1),]
      for (j in 1: (nknot-1)){
        knot = rbind(knot, popA1[(((i-1)*nknot)+j+1),])
      }
      GCV[i,] =  obj(y,s1,knot,nknot,p)
    }

    plotGCV=append(plotGCV,min(GCV))
    popA2=seleksi(popA1,GCV,b,nknot)
    popA3 = crossover(popA2,nknot)
    popA4=mutasi(popA3,nknot,b, pm=0.3)
    popA1=rbind(popA1,popA4)

  }
  model = data.frame('estimasi'=tetha(y, s1, knot, nknot, p))
  namknot=c();namvar=c();vari=c()
  for(i in 1:nknot){
    nama='Knot'
    namknot=append(namknot,paste(nama, i))
  }
  for(i in 1:nvar){
    nama='x'
    namvar=append(namvar,paste(nama,i,sep=""))
  }
  for (i in 1:nvar) {
    for(pangkat in 0:p[i]){
      if(pangkat == 0){
        vari=append(vari,paste('Betha',i,sep=''))
      }
      else if(pangkat==1){
        vari=append(vari,namvar[i])
      }
      else{
        vari=append(vari,paste(namvar[i],'^',pangkat,sep=''))
      }
      if (pangkat==p[i]){
        for (lambda in 1:nknot){
          vari=append(vari,paste('(',namvar[i],'-',namknot[lambda],')' ,'^',pangkat,sep=''))
        }
      }
    }
  }
  MAPE=residu(y, s1, knot, nknot, p)
  rownames(knot)=namknot;colnames(knot)=namvar;rownames(model)=vari

  cat('MAPE :  \n');cat(MAPE,'\n');cat('\n')
  cat('GCV :  \n');cat(min(plotGCV),'\n');cat('\n')
  cat('Orde Variabel :  \n');cat(p,'\n');cat('\n')
  cat('Titik Knot \n');print(knot);cat('\n')
  cat('Model Regresi : \n');print(model);cat('\n')

  hasil=list(
    'MAPE'= MAPE,
    'GCV'=min(plotGCV),
    'Orde Variabel'=p,
    'Titik Knot'=knot,
    'Model' = model
  )

}
