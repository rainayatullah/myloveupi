crossover = function(popA2,nknot){
  batas=nrow(popA2)
  while(batas%%(2*nknot)!=0) {
    batas=batas-1
  }
  for(i in seq(1,batas,by=2*nknot)){
    get1=popA2[i:(2*nknot+i-1),]
    get2= get1[nrow(get1):1,]
    get3=(get1 + get2)/2
    get4=(get3[1:2,])

    if(i==1){
      v4=get4
    } else{
      v4=rbind(v4,get4)
    }
  }
  v4
}
