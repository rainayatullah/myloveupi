euclidnorm =  function(b){
  norma=0
  for (i in 1:length(b)){
    norma = norma+b[i]^2
  }
  return(norma)
}
