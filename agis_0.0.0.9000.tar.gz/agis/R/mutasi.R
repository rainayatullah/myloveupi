mutasi = function(popA3,nknot,b, pm=0.3){
  pi=matrix(runif(((length(popA3)/b)/nknot),0,1))
  ran= sample(1:nknot)

  #mutas = sample(1:((length(popA3)/b)/nknot),((length(popA3)/b)/nknot))
  for (m in 1:((length(popA3)/b)/nknot)){
    li=popA3[(nknot*m-(nknot-1)):(nknot*m),]
    if (pi[m]<pm){
      for (j in 1:ncol(li)){
        li[,j]=li[ran,order(j)]
      }
    }
    if(m == 1){
      popA4 = li
    }
    else {
      popA4 = rbind(popA4,li)
    }
  }
  popA4
}
