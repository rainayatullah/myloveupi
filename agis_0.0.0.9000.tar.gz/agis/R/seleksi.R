#'@import stats
seleksi = function(popA1,GCV,b,nknot,T0=1,T1=0.0001,c=0.1){
  Fi = matrix (0,nrow=((length(popA1)/b)/nknot),ncol=1)
  for (i in 1:((length(popA1)/b)/nknot)){
    Fi[i,] = 1/(GCV[i,]+1)
  }

  #Build Probability
  Ftot = sum(Fi)
  F1 = matrix(Ftot, nrow = ((length(popA1)/b)/nknot), ncol = 1)
  pro = Fi/F1
  for (i in 1:((length(popA1)/b)/nknot)){
    Xnew = sample(1:((length(popA1)/b)/nknot),1)
    xi=Xnew
    t = T0
    F0 = Fi[Xnew]
    while (t > T1){
      xn = sample(1:((length(popA1)/b)/nknot),1)
      Fn = Fi[xn]
      if (Fn < F0){
        x = xn
      }
      else {
        delta = Fn - F0
        r= runif(1,0,1)
        if (r < exp(delta/t)){
          xi=xn
        }
      }
      t = t*c
    }
    if(i == 1){
      popA2 = popA1[(nknot*xi-(nknot-1)):(nknot*xi),]
    }
    else {
      popA2 = rbind(popA2,popA1[(nknot*xi-(nknot-1)):(nknot*xi),])
    }
  }
  popA2

}
