truncated = function(prediktor, knot, ord){
  if (isTRUE(prediktor > knot)){
    hasil=(prediktor - knot)^ord
  } else {
    hasil=0
  }
  return(hasil)
}
